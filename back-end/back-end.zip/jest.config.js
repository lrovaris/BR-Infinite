module.exports = {
  preset: '@shelf/jest-mongodb',
  globalTeardown : './test/teardown.js'
};
